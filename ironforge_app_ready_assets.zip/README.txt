IronForge app-ready icon pack

Included files
- ironforge-icon-master-transparent-2048.png
- Standard PNG sizes for web/PWA/app use
- favicon.ico
- Apple touch icons
- Maskable PNGs for Android/PWA launcher use

Suggested usage
- Web favicon: favicon.ico
- PWA manifest icon: ironforge-icon-192.png and ironforge-icon-512.png
- PWA maskable icon: ironforge-icon-maskable-192.png and ironforge-icon-maskable-512.png
- Apple touch icon: ironforge-icon-180-apple-touch.png
- App store / master source: ironforge-icon-1024.png or master transparent 2048

Notes
- These files preserve transparency.
- The icon has been padded to read better at small sizes.
